import React from 'react'

const HomePage = React.lazy(() => import('../components/home/Index'))
const User = React.lazy(() => import('../components/users/User'))
const Student = React.lazy(() => import('../components/students/Student'))
const Teacher = React.lazy(() => import('../components/teachers/Teacher'))
const Courses = React.lazy(() => import('../components/courses/Courses'))

//const Charts = React.lazy(() => import('./views/components/charts/Charts'))

const routes = [
   // { path: '/', exact: true, name: 'Home' },
   { path: '/', exact: true, name: 'Home', component: HomePage },
    { path: '/user', name: 'User', component: User },
    { path: '/students', name: 'Students', component: Student },
    { path: '/teachers', name: 'Teachers', component: Teacher },
    { path: '/courses', name: 'Courses', component: Courses },
    // { path: '/theme', name: 'Theme', component: Colors, exact: true },
    // { path: '/charts', name: 'Charts', component: Charts },
    // { path: '/forms', name: 'Forms', component: FormControl, exact: true },
    // { path: '/notifications', name: 'Notifications', component: Alerts, exact: true },
   
  ]
  
  export default routes