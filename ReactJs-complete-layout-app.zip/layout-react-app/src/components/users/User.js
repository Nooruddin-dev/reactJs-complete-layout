import React from 'react'


const User = () => {
  return (
    <div>
       <h>User Home Page</h>
    </div>
  )
}

export default User
