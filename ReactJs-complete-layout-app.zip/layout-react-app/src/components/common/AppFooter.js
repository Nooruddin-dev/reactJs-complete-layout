import React from 'react'


const AppFooter = () => {
  return (
    <div>
       <h>App Footer</h>
    </div>
  )
}

export default AppFooter
