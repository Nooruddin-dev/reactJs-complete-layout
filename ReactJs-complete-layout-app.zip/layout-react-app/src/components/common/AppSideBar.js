import React from 'react'
import { Link } from 'react-router-dom';

let url="";
  let element=<a href={url}>LinkedIn handle</a>;


const AppSideBar = () => {
  return (
    <nav id="sidebar">
    <div className="custom-menu">
        <button type="button" id="sidebarCollapse" className="btn btn-primary">
  <i className="fa fa-bars"></i>
  <span className="sr-only">Toggle Menu</span>
</button>
</div>
    <div className="p-4">
      <h1><a href="index.html" className="logo">Online <span>Exam System</span></a></h1>
<ul className="list-unstyled components mb-5">
  <li className="active">
    <Link to='/'><span className="fa fa-home mr-3"></span>Home</Link>
  </li>
  <li>

      <Link to='/teachers'><span className="fa fa-user mr-3"></span>Teachers</Link>
  </li>
  <li>

  <Link to='/students'><span className="fa fa-users mr-3"></span>Students</Link>
  </li>
  <li>

  <Link to='/courses'><span className="fa fa-university mr-3"></span>Courses</Link>
  </li>
  <li>

  <Link to='/categories'><span className="fa fa-suitcase mr-3"></span>Categories</Link>
  </li>

</ul>



<div className="footer">
    <p>
              All rights reserved | This template is made with <i className="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib.com</a>
             </p>
</div>

</div>
</nav>
  )
}

export default AppSideBar
