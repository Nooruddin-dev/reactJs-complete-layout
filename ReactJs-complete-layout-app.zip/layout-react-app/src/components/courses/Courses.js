
import React, { useState, useEffect } from 'react'
import axios from 'axios';



const Courses = () => {

    const [users, setUser] = useState([

        {
            id: 1,
            email: 'noor@gmail.com',
            name: 'noor'
        },
        {
            id: 2,
            email: 'khan@gmail.com',
            name: 'khan'
        },
        {
            id: 3,
            email: 'abid@gmail.com',
            name: 'abid'
        },
        {
            id: 4,
            email: 'jamshid@gmail.com',
            name: 'jamshid'
        }

    ]);




    return (
        <div>
            <form>
                <div className="row">
                    <div className="col">
                        <input type="number" className="form-control" placeholder="Course ID" />
                    </div>
                    <div className="col">
                        <input type="text" className="form-control" placeholder="Course name" />
                    </div>
                    <div className="col">
                        <button type="button" class="btn btn-outline-success">Search</button>
                    </div>
                </div>
            </form>

            <hr />

            <div className="row">
                <div className="col-lg-12">
                    <table className="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Course Name</th>
                                <th scope="col">Created On</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            {users.map(user => (

                                <tr key={user.id}>
                                    <th scope="row">{user.id}</th>
                                    <td>{user.name}</td>
                                    <td>{user.email}</td>
                                    <td></td>
                                </tr>

                            ))}
                        </tbody>
                    </table>
                </div>

            </div>

            <div className="row">
                <div className="col-md-12 col-lg-12">
                    <nav aria-label="...">
                        <ul class="pagination justify-content-end">
                            <li class="page-item disabled">
                                <span class="page-link">Previous</span>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item active">
                                <span class="page-link">
                                    2
                                    <span class="sr-only">(current)</span>
                                </span>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>

            </div>
        </div>
    )
}

export default Courses
