import React from 'react'


const Register = () => {
  return (
    <div>
       <h>Register</h>
    </div>
  )
}

export default Register
