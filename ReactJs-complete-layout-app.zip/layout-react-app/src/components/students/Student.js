import React from 'react'


const Student = () => {
    return (
        <div>
            <form>
                <div className="row">
                    <div className="col">
                        <input type="number" className="form-control" placeholder="Student ID" />
                    </div>
                    <div className="col">
                        <input type="text" className="form-control" placeholder="Student name" />
                    </div>
                    <div className="col">
                        <button type="button" class="btn btn-outline-success">Search</button>
                    </div>
                </div>
            </form>

            <hr />

            <div className="row">
                <div className="col-md-12 col-lg-12">
                    <div className="justify-content-end" style={{float: "right"}}>
                    <button type="button" className="btn btn-info ">Add New</button>
                    </div>
                   
                </div>

            </div>

            <div className="row">
                <div className="col-lg-12">
                    <table className="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Student Name</th>
                                <th scope="col">Created On</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>Mark</td>
                                <td>Otto</td>
                                <td>@mdo</td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>Jacob</td>
                                <td>Thornton</td>
                                <td>@fat</td>
                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td colspan="2">Larry the Bird</td>
                                <td>@twitter</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>

            <div className="row">
            <div className="col-md-12 col-lg-12">
                    <nav aria-label="...">
                        <ul class="pagination justify-content-end">
                            <li class="page-item disabled">
                                <span class="page-link">Previous</span>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item active">
                                <span class="page-link">
                                    2
                                    <span class="sr-only">(current)</span>
                                </span>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>

            </div>
        </div>
    )
}

export default Student
