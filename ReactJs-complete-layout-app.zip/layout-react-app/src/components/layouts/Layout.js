import React from 'react'
import AppContent from '../common/AppContent';
import AppFooter from '../common/AppFooter';
import AppHeader from '../common/AppHeader';
import AppSideBar from '../common/AppSideBar';
import '../common/AppSideBar.css'



const Layout = () => {
  return (
    <div className="wrapper d-flex align-items-stretch">
      <AppSideBar />
      <div id="content" class=" p-md-5 pt-5">
     
        <AppContent />
      </div>

    </div>
  )
}

export default Layout
